<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Supplier extends Model
{
    public $table = "supplier";
    use HasFactory;

    //tambahkan kode berikut
    protected $fillable = [
        'nama_bisnis', 'nama_bahan', 'kontak',
    ];
}