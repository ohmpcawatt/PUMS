@extends('template')
@section('content')
<div class="content">
    <div class="row mt-5">
        <div class="col-lg-12 margin-tb">
            <div class="float-start">
                <h3>Supplier</h3>
            </div>
            <div class="float-end">
                <a class="btn btn-success" href="{{ route('supplier.create') }}"> Create New supplier</a>
            </div>
        </div>
    </div>
    
   
    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif
   
    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Nama Bisnis</th>
            <th>Nama Bahan</th>
            <th>Kontak</th>
            <th width="280px">Action</th>
        </tr>
        @php $id = 1; @endphp
        @foreach ($supplier as $supplier)
        <tr>
            <td>{{ $id++ }}</td>
            <td>{{ $supplier->nama_bisnis }}</td>
            <td>{{ $supplier->nama_bahan }}</td>
            <td>{{ $supplier->kontak }}</td>
            <td>
                <form action="{{ route('supplier.destroy',$supplier->id) }}" method="POST">
                    <a class="btn btn-primary" href="{{ route('supplier.edit',$supplier->id) }}">Edit</a>
   
                    @csrf
                    @method('DELETE')
      
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
    </table>
   
</div>   
@endsection